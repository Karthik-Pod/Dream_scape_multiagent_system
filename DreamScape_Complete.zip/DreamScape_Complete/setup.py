"""
setup.py - Download required models
Run: python setup.py
"""
import os
import urllib.request
from pathlib import Path

def download_kokoro():
    """Download Kokoro TTS model (310 MB, one-time)"""
    url = "https://huggingface.co/hexgrad/Kokoro-82M/resolve/main/kokoro-v0_19.onnx"
    dest = Path("backend/kokoro-v0_19.onnx")
    
    if dest.exists():
        size_mb = dest.stat().st_size / (1024 * 1024)
        print(f"✅ Kokoro model already exists ({size_mb:.1f} MB)")
        return
    
    print(f"Downloading Kokoro TTS model (310 MB)...")
    print(f"Source: {url}")
    print(f"Destination: {dest}")
    print("\nThis may take 2-5 minutes depending on your connection...")
    
    dest.parent.mkdir(parents=True, exist_ok=True)
    
    def progress(block_num, block_size, total_size):
        downloaded = block_num * block_size
        percent = min(downloaded * 100 // total_size, 100)
        print(f"\r  Progress: {percent}% ({downloaded / (1024*1024):.1f} MB)", end="", flush=True)
    
    try:
        urllib.request.urlretrieve(url, str(dest), progress)
        print(f"\n✅ Successfully downloaded: {dest}")
        size_mb = dest.stat().st_size / (1024 * 1024)
        print(f"   File size: {size_mb:.1f} MB")
    except Exception as e:
        print(f"\n❌ Download failed: {e}")
        print(f"\nManual download:")
        print(f"  1. Visit: {url}")
        print(f"  2. Save to: {dest}")

if __name__ == "__main__":
    print("=" * 60)
    print("DreamScape — Model Setup")
    print("=" * 60)
    download_kokoro()
    print("\n" + "=" * 60)
    print("Setup complete! Run: python backend/main.py")
    print("=" * 60)
