# Magic Hour 401 Unauthorized — Troubleshooting Guide

## Problem
```
ERROR | generation.video_gen:generate_clip_for_scene:82 - 
Magic Hour error scene 1: status_code: 401, body: {'message': 'Unauthorized'}
```

## Root Cause
HTTP 401 = Invalid or missing API key

---

## Fix Steps

### Step 1: Check if API key is set
```bash
# In your project root
cat .env | grep MAGIC_HOUR
```

**Expected output:**
```
MAGIC_HOUR_API_KEY=mh_live_xxxxxxxxxxxxxxxxxxxxx
```

**If missing or empty:**
```bash
echo "MAGIC_HOUR_API_KEY=your_actual_key_here" >> .env
```

---

### Step 2: Get a valid API key

1. **Go to Magic Hour Dashboard:**
   https://magichour.ai/

2. **Sign up** (if you haven't):
   - Free tier gives you credits for testing
   - No credit card required

3. **Navigate to Developer/API section:**
   - Look for "API Keys" or "Developer"
   - Click "Create New Key" or "Generate API Key"

4. **Copy the key** (starts with `mh_live_` or similar)

5. **Add to .env:**
   ```bash
   # Open .env file
   nano .env
   
   # Add this line:
   MAGIC_HOUR_API_KEY=mh_live_your_actual_key_here
   
   # Save (Ctrl+O, Enter, Ctrl+X)
   ```

---

### Step 3: Verify the key works

Run the checker script:
```bash
python check_magic_hour.py
```

**Good output:**
```
✅ API Key found: mh_live_...
✅ API Key valid!
Account Info:
  Credits: 100
  Plan: free
```

**Bad output:**
```
❌ API Key is INVALID or EXPIRED
```
→ Go back to Step 2

---

### Step 4: Test video generation

```bash
python backend/main.py
```

When it reaches Phase 5:
```
=== PHASE 5: VIDEO CLIP GENERATION (MAGIC HOUR) ===
OK Magic Hour ready — animating 2 scenes
✅ Scene 1: ...  # Should succeed now
```

---

## Alternative: Skip Magic Hour (Use Static Images)

If you don't want to use Magic Hour or ran out of credits:

### Option A: Comment out the check in main.py

```python
# In backend/main.py, find:
if not settings.magic_hour_api_key:
    console.print("[yellow]WARNING MAGIC_HOUR_API_KEY not set...")
    
# Change to:
if True:  # Force skip Magic Hour
    console.print("[yellow]Skipping Magic Hour — using static images[/yellow]")
```

### Option B: Remove the key from .env

```bash
# In .env, comment out or delete:
# MAGIC_HOUR_API_KEY=...
```

Then the pipeline will use **Ken Burns effect** on static images instead of animated clips.

---

## Pipeline Behavior Without Magic Hour

Phase 5 will skip → Phase 6 VideoAssembler will:
1. Take static image from Phase 3 (Pollinations.AI)
2. Apply Ken Burns effect (slow zoom/pan)
3. Add your TTS + music from Phase 4
4. Output MP4 with animated camera on static image

**Result:** Still produces a video, just with camera movement instead of AI animation.

---

## Common Issues

### Issue 1: Key works in checker but fails in pipeline
**Cause:** Environment not reloaded
**Fix:**
```bash
# Restart your terminal, or:
source .env  # Linux/Mac
# OR just run pipeline in a fresh terminal
```

### Issue 2: 429 Rate Limit
**Cause:** Too many requests
**Fix:** Wait 1 hour or upgrade to paid tier

### Issue 3: Credits exhausted
**Cause:** Free tier credits used up
**Fix:** 
- Wait for monthly reset
- Upgrade to paid plan
- Use static image fallback

---

## Summary Decision Tree

```
Do you have a Magic Hour account?
├─ NO  → Go to magichour.ai, sign up, get API key
└─ YES → Do you have credits left?
         ├─ NO  → Use static image fallback (skip Magic Hour)
         └─ YES → Is key in .env?
                  ├─ NO  → Add MAGIC_HOUR_API_KEY to .env
                  └─ YES → Run check_magic_hour.py
                           ├─ FAIL → Generate new key
                           └─ PASS → Should work now
```

---

## For Your Demo/Report

If Magic Hour doesn't work:
1. ✅ **Use static images** — the pipeline handles this automatically
2. ✅ **Ken Burns effect** makes static images look professional
3. ✅ **Still produces a complete MP4** with narration + music

Your project deliverable is NOT dependent on Magic Hour — it's an optional enhancement.
