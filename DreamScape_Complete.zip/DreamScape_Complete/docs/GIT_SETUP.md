# SIMPLE FIX FOR GIT PUSH ERROR

## Problem
GitHub rejected your push because kokoro-v0_19.onnx is 310 MB (over 100 MB limit)

## Solution: Remove Model & Never Upload It

### Step 1: Remove Model from Git
```powershell
cd C:\Users\karth\OneDrive\Desktop\DreamScape
git rm --cached kokoro-v0_19.onnx
```

**Output should be:**
```
rm 'backend/kokoro-v0_19.onnx'
```

### Step 2: Update .gitignore
```powershell
echo "*.onnx" >> .gitignore
```

### Step 3: Commit Changes
```powershell
git add .gitignore
git commit -m "Remove large model file - users download separately"
```

**Output should be:**
```
[main xxxxxxx] Remove large model file - users download separately
 1 file changed, 1 insertion(+)
```

### Step 4: Push to GitHub
```powershell
git push -u origin main
```

**Output should show:**
```
✅ everything up to date (or similar success message)
```

---

## That's it! ✅

Your repository will push successfully WITHOUT the model file.

---

## What Users Do When They Clone

They only need to add the model file to their local machine:

### Option A: Auto-Download (Best)
Create `setup.py` in your project root:
```python
import os
import urllib.request

def download_kokoro():
    url = "https://huggingface.co/hexgrad/Kokoro-82M/resolve/main/kokoro-v0_19.onnx"
    dest = "backend/kokoro-v0_19.onnx"
    
    if os.path.exists(dest):
        print(f"✅ Model exists: {dest}")
        return
    
    print(f"Downloading Kokoro model (310 MB)... please wait")
    urllib.request.urlretrieve(url, dest)
    print(f"✅ Downloaded: {dest}")

if __name__ == "__main__":
    download_kokoro()
```

Users run after cloning:
```bash
python setup.py
```

### Option B: Manual Download
Users download from:
https://huggingface.co/hexgrad/Kokoro-82M

Place file at: `backend/kokoro-v0_19.onnx`

---

## Update README.md

Add this section:

```markdown
## Setup — First Time

1. Clone the repo
```bash
git clone https://github.com/Karthik-Pod/Dream_scape_multiagent_system.git
cd Dream_scape_multiagent_system
```

2. Install dependencies
```bash
pip install -r requirements.txt
```

3. Download Kokoro TTS model (310 MB, one-time)
```bash
python setup.py
```
or manually download from:
https://huggingface.co/hexgrad/Kokoro-82M/resolve/main/kokoro-v0_19.onnx
Place at: `backend/kokoro-v0_19.onnx`

4. Create .env file
```bash
cp .env.example .env
# Edit .env with your API keys
```

5. Run pipeline
```bash
python backend/main.py
```
```

---

## Summary

| Action | Command |
|--------|---------|
| Remove model from git | `git rm --cached kokoro-v0_19.onnx` |
| Update gitignore | `echo "*.onnx" >> .gitignore` |
| Commit | `git commit -m "Remove large model"` |
| Push | `git push -u origin main` |

**Result:** ✅ Repository pushed successfully, model stays local only
