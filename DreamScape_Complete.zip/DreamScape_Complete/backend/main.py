"""
backend/main.py
────────────────
DreamScape — Multi-Agent AI Storytelling Platform

CORRECT Pipeline Order:
  Phase 1  : Multi-agent story generation
  Phase 1B : Interactive story review loop
  Phase 2  : Scene pipeline (segment → structure → validate)
  Phase 3  : Image generation (Pollinations.AI — free, no key)
  Phase 4  : Audio generation FIRST (Kokoro TTS + MusicGen + mixer)
  Phase 5  : Video clip generation (Magic Hour — image → animated clip)
  Phase 6  : Final video assembly (FFmpeg merges clip + OUR audio)

Run from DreamScape root:
    python backend/main.py
"""
import sys, os, json, uuid
sys.path.append(os.path.dirname(__file__))

from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.table import Table

console = Console()

def main():
    console.print(Panel.fit(
        "[bold magenta]DREAMSCAPE[/bold magenta]\n"
        "[dim]Multi-Agent AI Storytelling Platform[/dim]",
        border_style="magenta",
    ))

    prompt   = Prompt.ask("\n[cyan]Enter your story prompt[/cyan]")
    rounds   = int(Prompt.ask("[cyan]Story rounds?[/cyan]", default="3"))
    story_id = f"story_{uuid.uuid4().hex[:8]}"
    console.print(f"[dim]Story ID: {story_id}[/dim]\n")

    os.makedirs("./storage/stories", exist_ok=True)
    os.makedirs("./storage/scenes",  exist_ok=True)

    console.print("[bold magenta]=== PHASE 1: STORY GENERATION ===[/bold magenta]")
    console.print("[yellow]Note: Connect your agents here[/yellow]")
    console.print(f"[green]Story ID: {story_id}[/green]")
    console.print(f"[green]Rounds: {rounds}[/green]")
    
    console.print("\n[bold magenta]=== PHASE 1B: STORY REVIEW ===[/bold magenta]")
    console.print("[yellow]After agents generate story, review loop will run here[/yellow]")
    
    console.print("\n[bold cyan]=== PHASE 2: SCENE PIPELINE ===[/bold cyan]")
    console.print("[yellow]Story will be segmented into scenes[/yellow]")
    
    console.print("\n[bold green]=== PHASE 3: IMAGE GENERATION ===[/bold green]")
    console.print("[yellow]Images will be generated for each scene[/yellow]")
    
    console.print("\n[bold yellow]=== PHASE 4: AUDIO GENERATION ===[/bold yellow]")
    console.print("[yellow]TTS narration and music will be created[/yellow]")
    
    console.print("\n[bold green]=== PHASE 5: VIDEO GENERATION ===[/bold green]")
    console.print("[yellow]Video clips will be generated[/yellow]")
    
    console.print("\n[bold blue]=== PHASE 6: VIDEO ASSEMBLY ===[/bold blue]")
    console.print("[yellow]Final MP4 will be assembled[/yellow]")
    
    console.print(f"\n[bold green]✅ Pipeline structure ready![/bold green]")
    console.print(f"  Story ID: {story_id}")
    console.print(f"  Output: ./storage/videos/{story_id}_final.mp4")

if __name__ == "__main__":
    main()
