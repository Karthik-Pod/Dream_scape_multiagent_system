"""
backend/config.py
Configuration management using pydantic-settings
"""
from pydantic_settings import BaseSettings
from pathlib import Path

class Settings(BaseSettings):
    # API Keys
    groq_api_key: str = ""
    gemini_api_key: str = ""
    magic_hour_api_key: str = ""
    
    # Storage
    storage_base: str = "./storage"
    chroma_persist_dir: str = "./storage/chroma"
    
    # Model settings
    image_model: str = "flux"
    tts_model: str = "kokoro"
    music_model: str = "musicgen-small"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

def get_settings() -> Settings:
    return Settings()
