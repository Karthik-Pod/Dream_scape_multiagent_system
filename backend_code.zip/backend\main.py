"""
backend/main.py - Day 6 version
Story → Scenes → Images → Video Clips (Kling AI) → Audio → Final Video
"""
import sys, os, json, uuid
sys.path.append(os.path.dirname(__file__))

from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel

from agents.plot_agent import PlotAgent
from agents.character_agent import CharacterAgent
from agents.emotion_agent import EmotionAgent
from agents.visual_agent import VisualAgent
from agents.audio_agent import AudioAgent
from coordinator.round_manager import RoundManager
from memory.story_state import StoryState
from memory.character_profiles import CharacterProfileStore
from memory.world_bible import WorldBible
from scene.pipeline import ScenePipeline
from generation.image_gen import ImageGenerator
from generation.video_gen import VideoGenerator
from generation.tts_gen import TTSGenerator
from generation.music_gen import MusicGenerator
from assembly.audio_mixer import AudioMixer
from assembly.video_assembler import VideoAssembler

console = Console()

def main():
    console.print(Panel.fit(
        "[bold magenta]DREAMSCAPE[/bold magenta]\n[dim]Multi-Agent AI Storytelling Platform[/dim]",
        border_style="magenta",
    ))

    prompt   = Prompt.ask("\n[cyan]Enter your story prompt[/cyan]")
    rounds   = int(Prompt.ask("[cyan]Story rounds?[/cyan]", default="3"))
    story_id = f"story_{uuid.uuid4().hex[:8]}"
    console.print(f"[dim]Story ID: {story_id}[/dim]\n")

    # PHASE 1: Story Generation
    console.print("[bold magenta]=== PHASE 1: STORY GENERATION ===[/bold magenta]")
    story_state        = StoryState(initial_prompt=prompt)
    character_profiles = CharacterProfileStore()
    world_bible        = WorldBible()
    agents = [PlotAgent(), CharacterAgent(), EmotionAgent(), VisualAgent(), AudioAgent()]

    manager = RoundManager(
        agents=agents, story_state=story_state,
        character_profiles=character_profiles,
        world_bible=world_bible, total_rounds=rounds,
    )
    manager.run_all_rounds()
    full_story = story_state.get_full_story()

    console.print("\n" + "="*60)
    console.print("[bold magenta]GENERATED STORY[/bold magenta]")
    console.print("="*60)
    console.print(full_story)

    os.makedirs("./storage/stories", exist_ok=True)
    with open(f"./storage/stories/{story_id}.json", "w") as f:
        json.dump(story_state.to_dict(), f, indent=2)

    # PHASE 2: Scene Pipeline
    console.print("\n[bold cyan]=== PHASE 2: SCENE PIPELINE ===[/bold cyan]")
    pipeline   = ScenePipeline()
    scene_list = pipeline.run(
        story_text=full_story,
        story_id=story_id,
        character_profiles=character_profiles.get_all(),
    )
    console.print(f"[green]OK {scene_list.total_scenes} scenes structured[/green]")

    # PHASE 3: Image Generation
    console.print("\n[bold green]=== PHASE 3: IMAGE GENERATION ===[/bold green]")
    img_gen = ImageGenerator()
    if img_gen.check_comfyui_running():
        console.print("[green]OK ComfyUI connected[/green]")
        image_paths = img_gen.generate_for_all_scenes(scene_list.scenes)
        for scene in scene_list.scenes:
            path = image_paths.get(scene.sequence_number)
            if path:
                scene.image_path = path
                console.print(f"  [green]OK[/green] Scene {scene.sequence_number}: {os.path.basename(path)}")
    else:
        console.print("[yellow]WARNING ComfyUI not running -- skipping image generation[/yellow]")
        image_paths = {}

    # PHASE 3B: Video Clip Generation (Kling AI)
    console.print("\n[bold green]=== PHASE 3B: VIDEO CLIP GENERATION (KLING AI) ===[/bold green]")
    clip_paths = {}
    scenes_with_images = [
        s for s in scene_list.scenes
        if image_paths.get(s.sequence_number)
    ]

    if scenes_with_images:
        video_gen  = VideoGenerator()
        clip_paths = video_gen.generate_clips_for_all_scenes(
            scenes_with_images, image_paths
        )
        success = sum(1 for v in clip_paths.values() if v)
        console.print(f"[green]OK {success}/{len(scenes_with_images)} video clips generated[/green]")
        for scene_num, path in clip_paths.items():
            if path:
                size_mb = os.path.getsize(path) / (1024 * 1024)
                console.print(f"  [green]OK[/green] Scene {scene_num}: {os.path.basename(path)} ({size_mb:.1f}MB)")
            else:
                console.print(f"  [yellow]WARN[/yellow] Scene {scene_num}: clip failed -- will use static image")
    else:
        console.print("[yellow]WARNING No images available -- skipping video clip generation[/yellow]")

    # PHASE 4: Audio Generation
    console.print("\n[bold yellow]=== PHASE 4: AUDIO GENERATION ===[/bold yellow]")

    console.print("\n[yellow]Step 4a: TTS Narration...[/yellow]")
    tts_gen     = TTSGenerator()
    tts_results = tts_gen.generate_for_all_scenes(scene_list.scenes)
    for r in tts_results:
        if r.get("narration_path"):
            console.print(f"  [green]OK[/green] {os.path.basename(r['narration_path'])}")

    console.print("\n[yellow]Step 4b: Background Music...[/yellow]")
    music_gen   = MusicGenerator(model_size="small")
    music_paths = music_gen.generate_for_all_scenes(scene_list.scenes)
    for scene_num, path in music_paths.items():
        if path:
            console.print(f"  [green]OK[/green] Scene {scene_num}: {os.path.basename(path)}")

    console.print("\n[yellow]Step 4c: Mixing Audio...[/yellow]")
    mixer       = AudioMixer()
    mixed_audio = mixer.mix_all_scenes(story_id, tts_results, music_paths)
    for scene_num, path in mixed_audio.items():
        if path:
            scene = next((s for s in scene_list.scenes if s.sequence_number == scene_num), None)
            if scene:
                scene.audio_path = path
            console.print(f"  [green]OK[/green] Scene {scene_num}: {os.path.basename(path)}")

    # PHASE 5: Video Assembly
    console.print("\n[bold blue]=== PHASE 5: VIDEO ASSEMBLY ===[/bold blue]")
    assembler = VideoAssembler()

    console.print("\n[blue]Step 5a: Assembling scene videos...[/blue]")
    scene_paths = assembler.assemble_all_scenes(
        scene_list.scenes,
        mixed_audio,
        clip_paths=clip_paths,
    )
    for path in scene_paths:
        if path:
            size_mb = os.path.getsize(path) / (1024 * 1024)
            console.print(f"  [green]OK[/green] {os.path.basename(path)} ({size_mb:.1f}MB)")

    console.print("\n[blue]Step 5b: Stitching final video...[/blue]")
    final_video = assembler.stitch_final_video(story_id, scene_paths)
    size_mb     = os.path.getsize(final_video) / (1024 * 1024)
    console.print(f"  [green]OK[/green] Final: {os.path.basename(final_video)} ({size_mb:.1f}MB)")

    # Save metadata
    os.makedirs("./storage/scenes", exist_ok=True)
    with open(f"./storage/scenes/{story_id}_scenes.json", "w") as f:
        json.dump(scene_list.model_dump(), f, indent=2, default=str)

    # Summary
    console.print(f"\n[bold green]Pipeline Complete![/bold green]")
    console.print(f"  Story  : ./storage/stories/{story_id}.json")
    console.print(f"  Scenes : ./storage/scenes/{story_id}_scenes.json")
    console.print(f"  Images : ./storage/images/")
    console.print(f"  Clips  : ./storage/videos/clips/")
    console.print(f"  Audio  : ./storage/audio/")
    console.print(f"  Video  : ./storage/videos/{story_id}_final.mp4")

if __name__ == "__main__":
    main()
