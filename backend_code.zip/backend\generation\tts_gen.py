"""
generation/tts_gen.py
──────────────────────
Text-to-Speech narration generation using Kokoro TTS.

Kokoro is:
  - Fully local (no API key needed)
  - High quality (beats ElevenLabs on many benchmarks)
  - Fast on CPU (no GPU needed)
  - Free and open source

For each scene it generates:
  1. Narration audio (the story prose read aloud)
  2. Per-character dialogue audio (different voice per character)

Output: WAV files saved to storage/audio/
"""
import sys, os, json
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from loguru import logger
from config import get_settings
from scene.schemas import Scene, NarrationStyle


# Voice mapping per narration style
# kokoro_onnx valid voices: af, af_bella, af_sarah, af_sky, am_adam, am_michael, bf_emma, bf_isabella, bm_george, bm_lewis
NARRATION_VOICES = {
    NarrationStyle.CALM:        "af_sarah",    # warm female voice
    NarrationStyle.DRAMATIC:    "am_michael",  # deep male voice
    NarrationStyle.URGENT:      "am_adam",     # energetic male
    NarrationStyle.WHISPERED:   "af_bella",    # soft female
    NarrationStyle.MELANCHOLIC: "bf_emma",     # British female, melancholic
}

# Character voice pool — assigned round-robin to characters
CHARACTER_VOICES = [
    "am_adam",
    "af_bella",
    "bm_george",
    "bf_emma",
    "am_michael",
    "af_sarah",
]


class TTSGenerator:
    """
    Generates TTS audio for scene narration and dialogue.
    Uses Kokoro TTS — runs fully locally on CPU.
    """

    def __init__(self):
        self.settings   = get_settings()
        self.output_dir = os.path.join(self.settings.storage_base, "audio")
        os.makedirs(self.output_dir, exist_ok=True)
        self._pipeline  = None
        self._char_voice_map: dict[str, str] = {}

    def _get_pipeline(self):
        """Lazy-load Kokoro pipeline — only initialized on first use."""
        if self._pipeline is None:
            logger.info("Loading Kokoro TTS model...")
            try:
                from kokoro_onnx import Kokoro
                import soundfile as sf
                # Store sf for use in _synthesize
                self._sf = sf
                self._pipeline = Kokoro("kokoro-v0_19.onnx", "voices.bin")
                logger.info("Kokoro TTS loaded successfully.")
            except ImportError:
                raise RuntimeError(
                    "Kokoro not installed. Run: pip install kokoro-onnx soundfile"
                )
        return self._pipeline

    def generate_narration(self, scene: Scene) -> str:
        """
        Generate narration audio for a scene's prose text.

        Args:
            scene: Scene object with narration_text and narration_style.

        Returns:
            Path to the generated WAV file.
        """
        logger.info(f"Generating narration for scene {scene.sequence_number}: {scene.title}")

        pipeline = self._get_pipeline()
        voice    = NARRATION_VOICES.get(scene.narration_style, "af_heart")
        text     = self._clean_text(scene.narration_text)

        filename    = f"{scene.story_id}_scene_{scene.sequence_number:02d}_narration.wav"
        output_path = os.path.join(self.output_dir, filename)

        self._synthesize(pipeline, text, voice, output_path)
        logger.info(f"Narration saved: {output_path}")
        return output_path

    def generate_dialogue(self, scene: Scene) -> list[dict]:
        """
        Generate per-character dialogue audio.
        Each character gets a consistent voice across all scenes.

        Returns:
            List of {character, text, audio_path}
        """
        if not scene.dialogue:
            return []

        pipeline = self._get_pipeline()
        results  = []

        for i, line in enumerate(scene.dialogue):
            # Assign consistent voice per character
            voice = self._get_character_voice(line.character)
            text  = self._clean_text(line.text)

            filename = (
                f"{scene.story_id}_scene_{scene.sequence_number:02d}"
                f"_dialogue_{i:02d}_{line.character.replace(' ', '_')}.wav"
            )
            output_path = os.path.join(self.output_dir, filename)

            self._synthesize(pipeline, text, voice, output_path)
            results.append({
                "character":  line.character,
                "text":       line.text,
                "emotion":    line.emotion,
                "audio_path": output_path,
            })

        return results

    def generate_for_scene(self, scene: Scene) -> dict:
        """
        Generate all audio for a scene (narration + dialogue).

        Returns:
            {
                "narration_path": "...",
                "dialogue": [{character, text, audio_path}],
                "scene_id": "..."
            }
        """
        result = {"scene_id": scene.scene_id, "narration_path": None, "dialogue": []}

        try:
            result["narration_path"] = self.generate_narration(scene)
        except Exception as e:
            logger.error(f"Narration failed for scene {scene.sequence_number}: {e}")

        try:
            result["dialogue"] = self.generate_dialogue(scene)
        except Exception as e:
            logger.error(f"Dialogue failed for scene {scene.sequence_number}: {e}")

        return result

    def generate_for_all_scenes(self, scenes: list[Scene]) -> list[dict]:
        """Generate audio for all scenes sequentially."""
        results = []
        total   = len(scenes)

        for i, scene in enumerate(scenes):
            logger.info(f"Audio {i+1}/{total}: {scene.title}")
            result = self.generate_for_scene(scene)
            results.append(result)
            logger.info(f"✅ Scene {scene.sequence_number} audio done.")

        return results

    def _synthesize(self, pipeline, text: str, voice: str, output_path: str) -> None:
        """
        Run Kokoro synthesis and save to WAV file.
        kokoro_onnx API: pipeline.create(text, voice, speed, lang)
        Returns (samples, sample_rate)
        """
        import soundfile as sf

        # kokoro_onnx returns (samples_array, sample_rate)
        samples, sample_rate = pipeline.create(
            text,
            voice=voice,
            speed=1.0,
            lang="en-us",
        )

        if samples is None or len(samples) == 0:
            raise RuntimeError(f"No audio generated for text: {text[:50]}")

        sf.write(output_path, samples, samplerate=sample_rate)

    def _clean_text(self, text: str) -> str:
        """
        Clean text for TTS — remove markdown, excessive punctuation.
        TTS models work better with clean prose.
        """
        import re
        # Remove markdown bold/italic
        text = re.sub(r'\*+', '', text)
        text = re.sub(r'_+', '', text)
        # Remove multiple spaces
        text = re.sub(r' +', ' ', text)
        # Remove multiple newlines
        text = re.sub(r'\n+', ' ', text)
        return text.strip()

    def _get_character_voice(self, character_name: str) -> str:
        """
        Assign a consistent voice to each character.
        Same character always gets same voice across all scenes.
        """
        if character_name not in self._char_voice_map:
            idx = len(self._char_voice_map) % len(CHARACTER_VOICES)
            self._char_voice_map[character_name] = CHARACTER_VOICES[idx]
            logger.debug(f"Voice assigned: {character_name} → {CHARACTER_VOICES[idx]}")
        return self._char_voice_map[character_name]
