"""
llm/client.py
─────────────
Groq LLM client with:
  - Singleton pattern (one client instance for the app lifetime)
  - Retry logic with exponential backoff (tenacity)
  - Token usage tracking per call
  - Structured logging
"""
import os
from groq import Groq
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from loguru import logger

# Import settings — reads from .env once
import sys
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from config import get_settings

_client: Groq | None = None


def get_client() -> Groq:
    """Singleton Groq client. Initialized once, reused forever."""
    global _client
    if _client is None:
        settings = get_settings()
        _client = Groq(api_key=settings.groq_api_key)
        logger.info("Groq client initialized.")
    return _client


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    retry=retry_if_exception_type(Exception),
    reraise=True,
)
def call_llm(
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.7,
    max_tokens: int = 1024,
    json_mode: bool = False,
) -> str:
    """
    Core LLM call function.

    Args:
        system_prompt: Role/behavior instruction for the agent.
        user_prompt:   The actual input content.
        temperature:   Creativity (0.0 = deterministic, 1.0 = creative).
        max_tokens:    Max output tokens.
        json_mode:     If True, forces the model to return valid JSON.

    Returns:
        Model response as a stripped string.
    """
    settings = get_settings()
    client = get_client()

    kwargs = {
        "model": settings.groq_model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_prompt},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    # JSON mode: forces model output to be valid JSON
    # Use this for all structured agent outputs
    if json_mode:
        kwargs["response_format"] = {"type": "json_object"}

    response = client.chat.completions.create(**kwargs)

    # Log token usage so you can track costs
    usage = response.usage
    logger.debug(
        f"LLM call | model={settings.groq_model} | "
        f"prompt_tokens={usage.prompt_tokens} | "
        f"completion_tokens={usage.completion_tokens} | "
        f"total={usage.total_tokens}"
    )

    return response.choices[0].message.content.strip()
