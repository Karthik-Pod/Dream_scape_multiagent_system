"""
generation/video_gen.py
────────────────────────
Converts scene images into real animated video clips using Kling AI API.

Flow per scene:
  1. Upload local image as base64
  2. Submit image-to-video task to Kling API
  3. Poll until completed (usually 2-4 min per scene)
  4. Download MP4 clip to storage/videos/clips/

These clips replace the static image in the final video assembly.
FFmpeg then merges each clip with its audio track.
"""
import os, sys, time, base64, requests
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from loguru import logger
from config import get_settings
from scene.schemas import Scene

# ── Kling API config ──────────────────────────────────────────────────────
KLING_API_URL  = "https://api.aimlapi.com/v2/video/generations"
KLING_MODEL    = "kling-video/v1/standard/image-to-video"
POLL_INTERVAL  = 15   # seconds between status checks
TIMEOUT        = 600  # 10 minutes max per scene


class VideoGenerator:
    """
    Generates animated video clips from scene images using Kling AI API.
    Each scene image becomes a 5-second animated video clip.
    """

    def __init__(self):
        self.settings  = get_settings()
        self.api_key   = self.settings.kling_api_key
        self.clips_dir = os.path.join(self.settings.storage_base, "videos", "clips")
        os.makedirs(self.clips_dir, exist_ok=True)

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type":  "application/json",
        }

    def _image_to_base64(self, image_path: str) -> str:
        """Convert local image file to base64 data URI for API upload."""
        with open(image_path, "rb") as f:
            data = base64.b64encode(f.read()).decode("utf-8")
        ext = os.path.splitext(image_path)[1].lower().replace(".", "")
        mime = "jpeg" if ext in ("jpg", "jpeg") else "png"
        return f"data:image/{mime};base64,{data}"

    def _build_video_prompt(self, scene: Scene) -> str:
        """Build a motion-focused prompt from the scene for better animation."""
        tone_motions = {
            "tense":       "slow camera push-in, tense atmosphere, subtle movement",
            "ominous":     "slow pan, dark shadows shifting, ominous drift",
            "hopeful":     "gentle zoom out, warm light rays, uplifting motion",
            "melancholic": "slow dolly back, soft focus drift, somber mood",
            "mysterious":  "slow orbital pan, mist swirling, ethereal movement",
            "triumphant":  "dramatic rise shot, epic sweep, heroic motion",
            "peaceful":    "gentle drift, soft breeze, calm floating motion",
            "fearful":     "slow zoom in, shadows closing, tense movement",
            "suspenseful": "slow rack focus, subtle tension, creeping motion",
            "joyful":      "bright zoom out, cheerful sweep, lively motion",
        }
        motion = tone_motions.get(scene.emotional_tone.value, "slow cinematic camera movement")
        return f"{motion}. Cinematic scene: {scene.visual_prompt[:150]}"

    def generate_clip_for_scene(self, scene: Scene, image_path: str) -> str | None:
        """
        Generate a 5-second animated video clip from a scene image.

        Args:
            scene:      Scene object with metadata
            image_path: Local path to the scene image (PNG/JPG)

        Returns:
            Local path to downloaded MP4 clip, or None if failed.
        """
        if not image_path or not os.path.exists(image_path):
            logger.error(f"Image not found for scene {scene.sequence_number}: {image_path}")
            return None

        logger.info(f"Animating scene {scene.sequence_number}: {scene.title}")

        # Convert image to base64
        image_b64 = self._image_to_base64(image_path)
        prompt    = self._build_video_prompt(scene)

        # Submit generation task
        payload = {
            "model":           KLING_MODEL,
            "image_url":       image_b64,
            "prompt":          prompt,
            "negative_prompt": "blurry, glitch, distorted, watermark, text overlay",
            "duration":        5,
            "cfg_scale":       0.5,
        }

        try:
            resp = requests.post(KLING_API_URL, json=payload, headers=self._headers(), timeout=30)
            resp.raise_for_status()
            gen_id = resp.json().get("id")
            if not gen_id:
                logger.error(f"No generation ID returned: {resp.text}")
                return None
            logger.info(f"Task submitted. Generation ID: {gen_id}")
        except Exception as e:
            logger.error(f"Failed to submit scene {scene.sequence_number}: {e}")
            return None

        # Poll until completed
        clip_path = self._poll_and_download(gen_id, scene)
        return clip_path

    def _poll_and_download(self, gen_id: str, scene: Scene) -> str | None:
        """Poll Kling API until video is ready, then download it."""
        start = time.time()

        while time.time() - start < TIMEOUT:
            time.sleep(POLL_INTERVAL)
            try:
                resp = requests.get(
                    KLING_API_URL,
                    params={"generation_id": gen_id},
                    headers=self._headers(),
                    timeout=15
                )
                data   = resp.json()
                status = data.get("status", "unknown")
                logger.info(f"Scene {scene.sequence_number} status: {status} "
                            f"({int(time.time()-start)}s elapsed)")

                if status == "completed":
                    video_url = data.get("video", {}).get("url")
                    if not video_url:
                        logger.error("Completed but no video URL in response.")
                        return None
                    return self._download_clip(video_url, scene)

                elif status == "error":
                    err = data.get("error", {})
                    logger.error(f"Generation failed: {err}")
                    return None

                # queued / generating — keep polling

            except Exception as e:
                logger.warning(f"Poll error (will retry): {e}")

        logger.error(f"Timeout after {TIMEOUT}s for scene {scene.sequence_number}")
        return None

    def _download_clip(self, url: str, scene: Scene) -> str:
        """Download generated MP4 clip to local storage."""
        filename  = f"{scene.story_id}_scene_{scene.sequence_number:02d}_clip.mp4"
        save_path = os.path.join(self.clips_dir, filename)

        logger.info(f"Downloading clip: {filename}")
        resp = requests.get(url, timeout=120, stream=True)
        resp.raise_for_status()

        with open(save_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)

        size_mb = os.path.getsize(save_path) / (1024 * 1024)
        logger.info(f"✅ Clip saved: {save_path} ({size_mb:.1f}MB)")
        return save_path

    def generate_clips_for_all_scenes(
        self,
        scenes: list[Scene],
        image_paths: dict[int, str]
    ) -> dict[int, str]:
        """
        Generate animated clips for all scenes.

        Args:
            scenes:      List of Scene objects
            image_paths: {sequence_number: image_path} from image generation phase

        Returns:
            {sequence_number: clip_path}  — None values mean that scene failed
        """
        results = {}
        total   = len(scenes)

        for i, scene in enumerate(scenes):
            img_path = image_paths.get(scene.sequence_number)
            logger.info(f"Animating scene {i+1}/{total}: {scene.title}")

            clip_path = self.generate_clip_for_scene(scene, img_path)
            results[scene.sequence_number] = clip_path

            if clip_path:
                logger.info(f"✅ Scene {scene.sequence_number} clip done.")
            else:
                logger.warning(f"⚠️ Scene {scene.sequence_number} clip failed — "
                               "will use static image fallback in video assembly.")

        return results
