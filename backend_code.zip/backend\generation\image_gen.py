"""
image_gen_comfyui.py  —  BACKUP (original ComfyUI version)
Keep this file. If diffusers fails, rename this to image_gen.py
"""
import sys, os, time, uuid, json, requests
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from loguru import logger
from config import get_settings
from scene.schemas import Scene

COMFYUI_URL = "http://127.0.0.1:8188"

class ImageGenerator:
    def __init__(self):
        self.settings   = get_settings()
        self.output_dir = os.path.join(self.settings.storage_base, "images")
        self.comfyui_url = COMFYUI_URL
        os.makedirs(self.output_dir, exist_ok=True)

    def check_comfyui_running(self) -> bool:
        try:
            r = requests.get(f"{self.comfyui_url}/system_stats", timeout=3)
            return r.status_code == 200
        except Exception:
            return False

    def generate_for_scene(self, scene: Scene) -> str:
        prompt   = self._enhance_prompt(scene)
        neg      = scene.negative_prompt or (
            "blurry, low quality, bad anatomy, watermark, text, ugly, deformed, "
            "glitch, chromatic aberration, oversaturated, colored dots, colored orbs, "
            "floating circles, lens flare orbs, bokeh balls, light leaks"
        )
        filename = f"{scene.story_id}_scene_{scene.sequence_number:02d}.png"
        out_path = os.path.join(self.output_dir, filename)

        for attempt in range(1, 4):
            try:
                prompt_id = self._queue_prompt(prompt, neg, seed=42 + scene.sequence_number * 100 + attempt)
                image_data = self._wait_for_image(prompt_id)
                with open(out_path, "wb") as f:
                    f.write(image_data)
                if self._is_valid_image(out_path):
                    logger.info(f"Image saved: {out_path}")
                    return out_path
                logger.warning(f"Invalid image attempt {attempt}, retrying...")
            except Exception as e:
                logger.warning(f"Attempt {attempt} failed: {e}")
                if attempt < 3:
                    time.sleep(10)
        logger.error(f"All attempts failed for scene {scene.sequence_number}")
        return None

    def generate_for_all_scenes(self, scenes: list[Scene]) -> dict[int, str]:
        results = {}
        for i, scene in enumerate(scenes):
            logger.info(f"Generating image {i+1}/{len(scenes)}: {scene.title}")
            path = self.generate_for_scene(scene)
            results[scene.sequence_number] = path
            if i < len(scenes) - 1:
                logger.info("Waiting 20s for VRAM to clear...")
                time.sleep(20)
        return results

    def _enhance_prompt(self, scene: Scene) -> str:
        style_prefix = "cinematic photography, dramatic lighting, high detail, "
        style_suffix = ", masterpiece, sharp focus, professional color grading"
        tone_keywords = {
            "tense": "high contrast shadows, dramatic tension",
            "ominous": "dark atmosphere, foreboding",
            "hopeful": "warm golden light, uplifting",
            "melancholic": "desaturated colors, somber mood",
            "mysterious": "fog, mist, ethereal glow",
            "triumphant": "epic lighting, heroic composition",
            "peaceful": "soft natural light, serene",
            "fearful": "harsh shadows, cold blue tones",
            "suspenseful": "low key lighting, tension",
            "joyful": "vibrant colors, warm sunlight",
        }
        tone_kw = tone_keywords.get(scene.emotional_tone.value, "")
        return f"{style_prefix}{scene.visual_prompt}{style_suffix}, {tone_kw}"

    def _queue_prompt(self, positive, negative, seed=42):
        workflow = json.loads(open("comfyui/workflows/sdxl_scene.json").read())
        for node in workflow.values():
            inputs = node.get("inputs", {})
            if node.get("class_type") == "CLIPTextEncode":
                if "positive" in str(node): inputs["text"] = positive
                else: inputs["text"] = negative
            if node.get("class_type") == "KSampler":
                inputs["seed"] = seed
        payload = {"prompt": workflow, "client_id": str(uuid.uuid4())}
        r = requests.post(f"{self.comfyui_url}/prompt", json=payload, timeout=10)
        return r.json()["prompt_id"]

    def _wait_for_image(self, prompt_id, timeout=300):
        start = time.time()
        while time.time() - start < timeout:
            r = requests.get(f"{self.comfyui_url}/history/{prompt_id}", timeout=5)
            data = r.json()
            if prompt_id in data:
                outputs = data[prompt_id].get("outputs", {})
                for node_output in outputs.values():
                    if "images" in node_output:
                        img = node_output["images"][0]
                        img_r = requests.get(
                            f"{self.comfyui_url}/view",
                            params={"filename": img["filename"], "subfolder": img["subfolder"], "type": img["type"]},
                            timeout=30
                        )
                        return img_r.content
            time.sleep(3)
        raise TimeoutError(f"Generation timed out after {timeout}s for prompt {prompt_id}")

    def _is_valid_image(self, path, min_size_kb=10):
        return os.path.exists(path) and os.path.getsize(path) > min_size_kb * 1024
